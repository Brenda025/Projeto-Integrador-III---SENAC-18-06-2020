package com.olympicos.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.olympicos.model.Academia;

import com.olympicos.repository.AcademiaRepository;

@Controller
public class AcademiaController {
	
	@Autowired
	private AcademiaRepository br;
 	
	@RequestMapping(value="/")
	    public String home() {
	        return "index";
	    }
	
	@RequestMapping(value="cadastrar")
	public ModelAndView listaAcademia(){
		ModelAndView mv = new ModelAndView("academia");
		Iterable<Academia> academia = br.findAll();
		mv.addObject("academia", academia);
		return mv;
	}
	 
	@RequestMapping(value="/cadastrar", method = RequestMethod.GET)
	    public String cadastrar() {
	        return "academia";
	    }
	@RequestMapping(value="/cadastrar", method = RequestMethod.POST)
	    public String cadastrar(Academia academia) {
	        br.save(academia);
			return "index";
	    }
	
	@PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, Model model) {
		Optional<Academia> academia = br.findById(id);
        br.deleteById(id);
        model.addAttribute("academia", br.findAll());
        return "academia";
    }
	
	@GetMapping("/{id}")
    public ModelAndView exibeid(@PathVariable("id") Long id) {
		Optional<Academia> optionalacademia = br.findById(id);
		Academia academia = optionalacademia.get();
		ModelAndView mv = new ModelAndView("formedit");
		mv.addObject("academia", academia);
        return mv;
    }

    @PostMapping("/{id}/update")
    public String atualiza(@PathVariable Long id,  @ModelAttribute Academia academia, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "formedit";
        }
        br.findById(id).get();
        br.save(academia);
        //model.addAttribute("academia", br.findAll());
        return "redirect:/academia";
    }
    
    @RequestMapping(value="/portfolio")
    public String portfolio() {
    	return "portfolio";
    }
	
	
	
	
	
	
}
