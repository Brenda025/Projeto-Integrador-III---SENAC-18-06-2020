package com.olympicos.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.olympicos.model.Academia;
import com.olympicos.model.Promocao;
import com.olympicos.repository.AcademiaRepository;
import com.olympicos.repository.PromocaoRepository;


public class PromocaoController {
	
	@Autowired
	private PromocaoRepository pro;
 	
	@RequestMapping(value="/")
	    public String home() {
	        return "promocao";
	    }
	
	@RequestMapping(value="/promocao")
	public ModelAndView listaPromocao(){
		ModelAndView mv = new ModelAndView("promocao");
		Iterable<Promocao> promocao = pro.findAll();
		mv.addObject("promocao", promocao);
		return mv;
	}
	 
	@RequestMapping(value="/cadastrar", method = RequestMethod.GET)
	    public String cadastrar() {
	        return "formpromocao";
	    }
	@RequestMapping(value="/cadastrar", method = RequestMethod.POST)
	    public String cadastrar(Promocao promocao) {
	        pro.save(promocao);
			return "redirect:/promocao";
	    }
	
	@PostMapping("/{id}/delete")
    public String delete(@PathVariable Integer id, Model model) {
		Optional<Promocao> promocao = pro.findById(id);
        pro.deleteById(id);
        model.addAttribute("promocao", pro.findAll());
        return "promocao";
    }
	
	@GetMapping("/{id}")
    public ModelAndView exibeid(@PathVariable("id") Integer id) {
		Optional<Promocao> optionalpromocao = pro.findById(id);
		Promocao promocao = optionalpromocao.get();
		ModelAndView mv = new ModelAndView("formedit");
		mv.addObject("promocao", promocao);
        return mv;
    }
	
	@PostMapping("/{id}/update")
    public String atualiza(@PathVariable Integer id,  @ModelAttribute Promocao promocao, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "formedit";
        }
        pro.findById(id).get();
        pro.save(promocao);
        //model.addAttribute("academia", br.findAll());
        return "redirect:/promocao";
    }
	

}
