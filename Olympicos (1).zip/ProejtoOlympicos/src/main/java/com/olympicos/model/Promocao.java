package com.olympicos.model;
import javax.persistence.*;

@Entity
@Table(name="promocao")
public class Promocao {
	
	@Id
	@GeneratedValue( strategy= GenerationType.AUTO )
	private int pid;
	@Column(name="mensalidade")
	private int mensalidade;
	@Column(name="descontoPrimeiroMes")
	private int descontoPrimeiroMes;
	@Column(name="pacoteTrimestral")
	private int pacoteTrimestral;
	@Column(name="indicacaoDeAmigo")
	private boolean indicacaoDeAmigo;
	
	public Promocao() {
		
	}

	public int getMensalidade() {
		return mensalidade;
	}

	public void setMensalidade(int mensalidade) {
		this.mensalidade = mensalidade;
	}

	public int getDescontoPrimeiroMes() {
		return descontoPrimeiroMes;
	}

	public void setDescontoPrimeiroMes(int descontoPrimeiroMes) {
		this.descontoPrimeiroMes = descontoPrimeiroMes;
	}

	public int getPacoteTrimestral() {
		return pacoteTrimestral;
	}

	public void setPacoteTrimestral(int pacoteTrimestral) {
		this.pacoteTrimestral = pacoteTrimestral;
	}

	public boolean isIndicacaoDeAmigo() {
		return indicacaoDeAmigo;
	}

	public void setIndicacaoDeAmigo(boolean indicacaoDeAmigo) {
		this.indicacaoDeAmigo = indicacaoDeAmigo;
	}
	
	
}
