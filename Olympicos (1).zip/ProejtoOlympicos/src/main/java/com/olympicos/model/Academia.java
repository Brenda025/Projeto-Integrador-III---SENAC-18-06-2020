package com.olympicos.model;
import javax.persistence.*;

@Entity
@Table(name="academia")
public class Academia {
	
	@Id
	@GeneratedValue( strategy= GenerationType.AUTO )
	@Column(name="matricula")
	private int matricula;
	@Column(name="nome")
	private String nome;
	@Column(name="endereco")
	private String endereco;
	@Column(name="bairro")
	private String bairro;
	@Column(name="numero")
	private int numero;
	@Column(name="telefone")
	private int telefone;
	@Column(name="email")
	private String email;
	@OneToOne
	private Academia pid;
	
	public Academia() {
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
