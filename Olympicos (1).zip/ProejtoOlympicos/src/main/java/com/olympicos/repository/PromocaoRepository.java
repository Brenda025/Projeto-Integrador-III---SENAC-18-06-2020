package com.olympicos.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.olympicos.model.Promocao;

@Repository
public interface PromocaoRepository extends CrudRepository<Promocao, Integer>{

}
